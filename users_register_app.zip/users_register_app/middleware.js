const fs = require("node:fs")


const validateInput = (req,res,next)=>{
    const {name, email} = req.body
    if(!email.includes("@")){
        return res.status(400).json({message:"Invalid email"})
    }if(!name){
        return res.status(400).json({message:"Name is required"})
    }
    const newUser = {
        id: Date.now(),
        name,
        email
    }
    req.user=newUser
    next()
}

module.exports={validateInput}