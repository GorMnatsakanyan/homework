import React, {useState} from "react";

// import Card from './components/Card/Card.jsx'
import Button from './components/Button/Button.jsx'
import Fact from "./components/Fact/Fact.jsx";
import Card from "./components/Card/Card.jsx";
import Header from "./components/Header/Header.jsx";
import CarGallery from "./components/CarGallery.jsx";

function App(){
  //  const facts = [
  //   "Gor 18 tarekan",
  //   "Cnvel e Yerevanum"
  //  ]

  //  const [count, setCount] = useState(0)
  //  const increment = ()=>setCount(count+1)
  //  const decrement = ()=>setCount(count-1)
   
  //  const [text, setText] = useState("hello")
  //  const changeToText1 = ()=>setText("hellotxt1")
  //  const changeToText2 = ()=>setText("hellotxt2")

  //  const [active, setActive] = useState("")

  const [activeBrand, setActiveBrand]=useState("All")

   
  return(
    <div>
      {/* <h1>Counter: {count}</h1>
      <Button text="Increase" onClick={increment}/>
      <Button text="Decrease" onClick={decrement}/>

      <Fact data={facts}/>

      <Button text="text1" onClick={changeToText1}/>
      <Button text="text2" onClick={changeToText2}/>
      <h3>{text}</h3>

      <Card 
       title="HTML"
       active={active}
       setActive={setActive}
      />
      <Card
       title="CSS"
       active={active}
       setActive={setActive}
      />
      <Card 
       title="JS"
       active={active}
       setActive={setActive}
      /> */}
      <Header onSelectBrand={setActiveBrand} activeBrand={activeBrand}/>
      <CarGallery activeBrand={activeBrand} />

    </div>

    


  )
}

export default App;

