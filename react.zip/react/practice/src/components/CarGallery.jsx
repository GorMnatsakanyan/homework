import React from "react";

import "./CarGallery.css"

const cars = [
    {id: 1, brand: "Mercedes", img: "merc1.jpg"},
    {id: 2, brand: "Mercedes", img: "merc2.jpg"},
    {id: 3, brand: "Mercedes", img: "merc3.jpg"},
    {id: 4, brand: "BMW", img: "bmw1.jpg"},
    {id: 5, brand: "BMW", img: "bmw2.jpg"},
    {id: 6, brand: "BMW", img: "bmw3.jpg"},
    {id: 7, brand: "Audi", img: "audi1.jpg"},
    {id: 8, brand: "Audi", img: "audi2.jpg"},
    {id: 9, brand: "Audi", img: "audi3.jpg"}
]

const CarGallery = ({activeBrand})=>{
    const filteredCars = activeBrand ==="All"?cars:cars.filter(c=>c.brand===activeBrand)
    
    return(
        <div className="gallery">
            {filteredCars.map((car)=> (
                <div key={car.id} className="car-card">
                    <img src={`${car.img}`} alt={car.brand} />
                    <p>{car.brand}</p>
                </div>
            ))}
        </div>
    )
}

export default CarGallery


