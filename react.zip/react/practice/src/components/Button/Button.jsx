import React from "react";

function Button({text, onClick}){
    // const handleClick = ()=>{
    //     // alert("Hello")
    // }

    return (
        <button onClick={onClick}>
         {text}
        </button>
    )
}

export default Button
