// import React from "react"
import React, {useState} from "react";

  
function Card({title, active, setActive}){
  const handleClick = ()=>{
    setActive(title)
  }

  return (
    <div 
     onClick={handleClick}
     style={{
      padding:20,
      margin: 10,
      backgroundColor: "lightgray",
      borderRadius: 10,
      width: 200,
      fontWeight: "bold",
      cursor: "pointer"
     }}
    >
     <h3>{title}</h3>
      {active === title && <p>Hello {title}</p>}     
    </div>

  )
}

export default Card