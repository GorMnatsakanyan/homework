import React from "react";

function Fact({data}){
    return(
        <div>
           <h2>Facts</h2> 
           <ul>
            {data.map((fact,index)=>(
                <li key={index}>{fact}</li>
            ))}
           </ul>
        </div>
    )
}
export default Fact