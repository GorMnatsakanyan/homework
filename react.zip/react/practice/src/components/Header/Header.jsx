import React from "react"

import "./Header.css"

const Header = ({onSelectBrand, activeBrand})=>{
    return (
        <header className="header">
            <nav className="nav">
              <ul className="nav-list">
                {["All", "Mercedes", "BMW", "Audi"].map((brand) => (
                 <li key={brand}>
                 <button
                  className={activeBrand === brand ? "active" : ""}
                  onClick={() => onSelectBrand(brand)}
                 >
                 {brand}
                </button>
            </li>
          ))}

              </ul>
            </nav>
        </header>
    )
}

export default Header
