const express = require("express")
const PORT = 3000
const app = express()
const {validateInput} = require("./middleware")
const fs = require("node:fs")
app.use(express.json())

app.get("/messages", (req,res)=>{
    const data = fs.readFileSync("messages.json", {encoding:"utf-8"})
    const messages = JSON.parse(data)
    res.status(200).json(messages)
})

app.post("/messages", validateInput, (req, res)=>{
    const message = req.message
    if(!message){
        return res.status(500).json({message: "Internal server error"})
    }
    const data = fs.readFileSync("messages.json", {encoding: "utf-8"})
    const messages = JSON.parse(data)
    messages.push(message)
    fs.writeFileSync("messages.json", JSON.stringify(messages, null, 2))
    res.status(200).json({message: "Message is created"})
})



app.listen(PORT, ()=>{
  console.log(`Server is running on ${PORT}`)
})