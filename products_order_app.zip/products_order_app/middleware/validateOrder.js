const fs = require("fs")

function validateOrder(req, res, next) {
  const { customer, products } = req.body

  if (!customer || customer.length < 2) {
    return res.status(400).json({ message: "Customer name must have at least 2 characters" })
  }

  if (!Array.isArray(products) || products.length === 0) {
    return res.status(400).json({ error: "Invalid order data" })
  }

  const productsData = fs.readFileSync("products.json", "utf-8")
  const allProducts = JSON.parse(productsData)

  const hasValidProduct = products.some(id =>
    allProducts.some(p => p.id === id)
  );

  if (!hasValidProduct) {
    return res.status(400).json({ error: "Invalid order data" })
  }

  next()
 
  
}

module.exports = validateOrder