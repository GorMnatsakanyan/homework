function validateProduct(req,res,next){
    const{name,price} = req.body
    if(!name || name.length<2){
        return res.status(400).json({ message: "Product name must have at least 2 characters" })
    }
    if(price<=0){
       return res.status(400).json({ message: "Invalid product data" })
    }
    next()
}

module.exports = validateProduct
