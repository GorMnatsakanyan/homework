const express = require("express")
const PORT = 3001
const app = express()
const {validateInput, validateProductIdInput} = require("./middleware")
const fs = require("node:fs")
app.use(express.json())

app.get("/products", (req,res)=>{
    const data = fs.readFileSync("products.json", {encoding:"utf-8"})
    const products = JSON.parse(data)
    res.status(200).json(products)
})


app.get("/products/:id", (req,res)=>{
  const {id}=req.params
  if(!id){
    return res.status(400).json({message:"ID missing"})
  }
  const data = fs.readFileSync("products.json", {encoding:"utf-8"})
  const products = JSON.parse(data)
  const found = products.find(u=> u.id==id)
  if(!found){
    return res.status(400).json({message:"Product not found"})
  }
  res.status(200).json(found)
})

app.get("/orders", (req,res)=>{
  const data = fs.readFileSync("orders.json", {encoding:"utf-8"})
  const orders = JSON.parse(data)
  res.status(200).json(orders)
})

app.get("/orders/:id", (req,res)=>{
  const {id} = req.params
  if(!id){
    return res.status(400).json({message:"ID missing"})
  } 
  const data = fs.readFileSync("orders.json", {encoding:"utf-8"})
  const orders = JSON.parse(data)
  const found = orders.find(u=> u.id==id)
  if(!found){
    return res.status(400).json({message:"Order not found"})
  }
  res.status(200).json(found)

})

app.put("/orders/:id", (req,res)=>{
  const {id} = req.params
  const {customer, productId} = req.body

  if(!id){
    return res.status(400).json({message: "ID is missing"})
  }
  const data = fs.readFileSync("orders.json", {encoding:"utf-8"})
  const orders = JSON.parse(data)
  const order = orders.find(o=> o.id == id)
  if(!order){
    return res.status(400).json({message: "Order not found"})
  }
  if(customer) order.customer=customer
  if(productId) order.productId=productId

  fs.writeFileSync("orders.json", JSON.stringify(orders, null, 2));
  res.status(200).json({message:"Order updated successfully", updatedOrder:order})
})

app.put("/products/:id", (req,res)=>{
    const{id}=req.params
    const {name,price}=req.body

    if(!id){
        return res.status(400).json({message:"ID is missing"})
    }
    const data = fs.readFileSync("products.json", {encoding:"utf-8"})
    const products = JSON.parse(data)

    const product = products.find(p => p.id == id);

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    if (name) product.name = name;
    if (price) product.price = price;

    fs.writeFileSync("products.json", JSON.stringify(products, null, 2));
    res.status(200).json({message:"Product updated successfully", updatedProduct:product})
})

app.delete("/products/:id", (req,res)=>{
    const{id}=req.params

    const data = fs.readFileSync("products.json", {encoding:"utf-8"})
    const products = JSON.parse(data)

    const product = products.find(p => p.id == id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    const updatedProducts = products.filter(p => p.id != id);
    fs.writeFileSync("products.json", JSON.stringify(updatedProducts, null, 2));

    res.status(200).json({ message: "Product deleted successfully", deletedProduct: product});
})

app.delete("/orders/:id", (req,res)=>{
    const{id}=req.params

    const data = fs.readFileSync("orders.json", {encoding:"utf-8"})
    const orders = JSON.parse(data)

    const order = orders.find(o => o.id == id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    const updatedOrders = orders.filter(o => o.id != id);
    fs.writeFileSync("orders.json", JSON.stringify(updatedOrders, null, 2));

    res.status(200).json({ message: "Order deleted successfully", deletedOrder: order});
})


app.post("/orders", validateProductIdInput, (req,res)=>{
  const order = req.order
  const product = req.product
  if(!order){
    return res.status(500).json({message: "Internal server error"})
  }
  const data = fs.readFileSync("orders.json", {encoding:"utf-8"})
  const orders = JSON.parse(data)
  orders.push(order)
  fs.writeFileSync("orders.json", JSON.stringify(orders,null,2))
  res.status(200).json({message: "Order created successfully", product:{name:product.name, price:product.price}})
})

app.post("/products", validateInput, (req,res)=>{
    const product = req.product
    if(!product){
        return res.status(500).json({message: "Internal server error"})
    }
    const data = fs.readFileSync("products.json", {encoding:"utf-8"})
    const products = JSON.parse(data)
    products.push(product)
    fs.writeFileSync("products.json", JSON.stringify(products, null, 2))
    res.status(200).json({message: "Product created successfully"})
})


app.listen(PORT, ()=>{
  console.log(`Server is running on ${PORT}`)
})