const fs = require("node:fs")

const validateInput = (req,res,next)=>{
    const {name, price} = req.body
    if(!name){
        return res.status(400).json({message:"Product is required"})
    }
    if(!price){
        return res.status(400).json({message: "Price is required"})
    }
    const newProduct = {
        id: Date.now(),
        name,
        price
    }
    req.product=newProduct
    next()
}

const validateProductIdInput = (req,res,next)=>{
    const {customer, productId} = req.body
    if(!customer){
        return res.status(400).json({message:"Your name is required"})
    }
    if(!productId){
        return res.status(400).json({message: "Product id is required"})
    }
    const productsData = fs.readFileSync("products.json", {encoding: "utf-8"})
    const products = JSON.parse(productsData)

    const productExists = products.find(p=>p.id===productId)
    if(!productExists){
        return res.status(400).json({message:"Invalid product Id"})
    }
    const newOrder = {
        id: Date.now(),
        customer,
        productId
    }
    req.order = newOrder
    req.product = productExists
    next()
}

module.exports={validateInput, validateProductIdInput}