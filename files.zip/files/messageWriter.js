const fs = require("node:fs")
const message = "Hello bolorin"
fs.writeFileSync("message.txt", message, "utf-8")

module.exports = {}
