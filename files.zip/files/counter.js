const fs = require("node:fs")
const data = fs.readFileSync("text.txt", "utf-8")

function qanak(data){
    let a = data.split(" ");
    let chap = a.length
    return chap
}
console.log(qanak(data))
let result = qanak(data)
fs.writeFileSync("result.txt", result.toString(), "utf-8")
