const fs = require("node:fs")

function toCopy(copy,paste){
    const data = fs.readFileSync(copy, "utf-8")
    fs.writeFileSync(paste, data, "utf-8")
}
module.exports = toCopy