const fs = require("node:fs")
const data1 = fs.readFileSync("file1.txt", "utf-8")
const data2 = fs.readFileSync("file2.txt", "utf-8")
console.log(data1)
console.log(data2)
fs.writeFileSync("merged.txt", data1 + "\n" + data2, "utf-8")


